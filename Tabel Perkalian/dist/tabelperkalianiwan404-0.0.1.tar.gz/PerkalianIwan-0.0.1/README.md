# MyLibrary

MyLibrary adalah sebuah library sederhana untuk melakukan perhitungan perkalian dan menampilkan tabel perkalian.

## Instalasi

Anda dapat menginstal library ini menggunakan pip:

```bash
pip install tabelperkalian
```
