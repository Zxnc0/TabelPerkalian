from tabelperkalian import Calculator

calc = Calculator()
angka = 3
calc.multiplication_table(angka)